package com.example.myapplication.ui.slideshow;

import android.app.Activity;

public class ReadingFragment extends Activity {
}
